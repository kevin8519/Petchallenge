-- phpMyAdmin SQL Dump
-- version 4.0.10.14
-- http://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: Oct 17, 2016 at 07:49 AM
-- Server version: 5.5.49-cll-lve
-- PHP Version: 5.6.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `thanappanalkevinshop`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE IF NOT EXISTS `admins` (
  `user_id` int(100) NOT NULL AUTO_INCREMENT,
  `user_email` varchar(255) NOT NULL,
  `user_pass` varchar(255) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`user_id`, `user_email`, `user_pass`) VALUES
(1, 'kevin@gmail.com', 'kevin'),
(2, 'minu@gmail.com', 'minu');

-- --------------------------------------------------------

--
-- Table structure for table `breeds`
--

CREATE TABLE IF NOT EXISTS `breeds` (
  `breed_id` int(100) NOT NULL AUTO_INCREMENT,
  `breed_title` text NOT NULL,
  PRIMARY KEY (`breed_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `breeds`
--

INSERT INTO `breeds` (`breed_id`, `breed_title`) VALUES
(1, 'Native'),
(2, 'Foreign');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE IF NOT EXISTS `cart` (
  `p_id` int(20) NOT NULL,
  `ip_add` varchar(255) NOT NULL,
  `qty` int(20) NOT NULL,
  PRIMARY KEY (`p_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `cat_id` int(100) NOT NULL AUTO_INCREMENT,
  `cat_title` text NOT NULL,
  PRIMARY KEY (`cat_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cat_id`, `cat_title`) VALUES
(2, 'Cats'),
(3, 'Reptiles'),
(4, 'Pet Toys'),
(5, 'Pet Carriers'),
(6, 'Birds'),
(7, 'Dogs');

-- --------------------------------------------------------

--
-- Table structure for table `color`
--

CREATE TABLE IF NOT EXISTS `color` (
  `color_id` int(100) NOT NULL AUTO_INCREMENT,
  `color_title` text NOT NULL,
  PRIMARY KEY (`color_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `color`
--

INSERT INTO `color` (`color_id`, `color_title`) VALUES
(1, 'Black'),
(2, 'White'),
(3, 'brown'),
(4, 'green'),
(5, 'grey'),
(6, 'yellow');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE IF NOT EXISTS `customers` (
  `customer_id` int(100) NOT NULL AUTO_INCREMENT,
  `customer_ip` varchar(255) NOT NULL,
  `customer_name` text NOT NULL,
  `customer_email` varchar(100) NOT NULL,
  `customer_pass` varchar(100) NOT NULL,
  `customer_country` text NOT NULL,
  `customer_city` text NOT NULL,
  `customer_contact` varchar(255) NOT NULL,
  `customer_image` text NOT NULL,
  `customer_address` text NOT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`customer_id`, `customer_ip`, `customer_name`, `customer_email`, `customer_pass`, `customer_country`, `customer_city`, `customer_contact`, `customer_image`, `customer_address`) VALUES
(2, '::1', 'kevin', 'thana@gmail.com', 'kevin', 'Nepal', 'Las', 'aapdasdakdo', '26bradman.jpg', 'ferbfregergergberjgberbgerjgb'),
(3, '::1', 'pinu', 'min@gmail.com', 'minu', 'Belgium', 'cb', 'ddf444', '26bradman.jpg', 'rwureteth'),
(5, '::1', 'minu', 'min@gmail.com', 'minu', '', 'cb', 'ddf444', '', 'rwureteth'),
(6, '::1', 'minu', 'min@gmail.com', 'minu', '', 'cb', 'ddf444', '', 'rwureteth'),
(7, '::1', 'minu', 'min@gmail.com', 'minu', '', 'cb', 'ddf444', '', 'rwureteth'),
(8, '104.139.102.181', 'sam', 'sam@gmail.com', 'sam', 'Germany', 'berlin', 'fewfewfw', 'car.jpg', 'dferferf'),
(9, '104.139.102.181', 'Kevin Jose Thana', 'kthana16apr@gmail.com', 'kevin', 'United States', 'Charlotte', '567890', 'Cat1.jpg', '7816 rewtert');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `order_id` int(100) NOT NULL AUTO_INCREMENT,
  `p_id` int(100) NOT NULL,
  `c_id` int(100) NOT NULL,
  `qty` int(100) NOT NULL,
  `invoice_no` int(100) NOT NULL,
  `order_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` text NOT NULL,
  PRIMARY KEY (`order_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `p_id`, `c_id`, `qty`, `invoice_no`, `order_date`, `status`) VALUES
(1, 5, 3, 1, 0, '2016-10-17 11:02:14', 'Completed'),
(2, 9, 3, 1, 328052290, '2016-10-17 08:23:19', '0'),
(3, 4, 9, 1, 389747335, '2016-10-17 12:09:45', 'inProgress');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE IF NOT EXISTS `payments` (
  `payment_id` int(100) NOT NULL AUTO_INCREMENT,
  `amount` int(100) NOT NULL,
  `customer_id` int(100) NOT NULL,
  `product_id` int(100) NOT NULL,
  `trx_id` varchar(255) NOT NULL,
  `currency` varchar(100) NOT NULL,
  `payment_date` date NOT NULL,
  PRIMARY KEY (`payment_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`payment_id`, `amount`, `customer_id`, `product_id`, `trx_id`, `currency`, `payment_date`) VALUES
(1, 350, 3, 5, '1F3508579J640701H', 'USD', '0000-00-00'),
(2, 525, 3, 9, '4M498123HF2811330', 'USD', '2016-10-17'),
(3, 560, 9, 4, '84T74864TG4087333', 'USD', '2016-10-17');

-- --------------------------------------------------------

--
-- Table structure for table `pets`
--

CREATE TABLE IF NOT EXISTS `pets` (
  `pet_id` int(100) NOT NULL AUTO_INCREMENT,
  `pet_cat` int(100) NOT NULL,
  `pet_breed` int(100) NOT NULL,
  `pet_title` varchar(255) NOT NULL,
  `pet_price` int(100) NOT NULL,
  `pet_color` int(100) NOT NULL,
  `pet_lifespan` int(100) NOT NULL,
  `pet_age` int(100) NOT NULL,
  `pet_des` text NOT NULL,
  `pet_image` text NOT NULL,
  `pet_keywords` text NOT NULL,
  PRIMARY KEY (`pet_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `pets`
--

INSERT INTO `pets` (`pet_id`, `pet_cat`, `pet_breed`, `pet_title`, `pet_price`, `pet_color`, `pet_lifespan`, `pet_age`, `pet_des`, `pet_image`, `pet_keywords`) VALUES
(1, 7, 1, 'Dog     ', 700, 1, 40, 30, '<p>Good Dog</p>', 'Dalmesian.jpg', 'dog dalmesian'),
(3, 2, 1, 'Cute little cat', 600, 3, 10, 6, '<p>Nice cat</p>', 'Cat2.jpg', 'cats'),
(4, 2, 2, 'Nice cat', 800, 3, 15, 8, '<p>Nice</p>', 'Cat3.jpg', 'Cats'),
(5, 7, 0, 'Cute Dog ', 500, 0, 40, 30, '<p>Nice</p>', 'Dog1.jpg', 'Dog'),
(6, 7, 0, 'Puppy ', 700, 0, 20, 2, '<p>Nice</p>', 'Dog3.jpg', 'Nice'),
(7, 4, 1, 'Toys', 50, 1, 10, 1, '<p>Nice</p>', 'pettoys.jpg', 'pet toy'),
(8, 3, 2, 'Tortoise', 1000, 5, 100, 20, '<p>good</p>', 'reptile1.jpg', 'tortoise'),
(9, 3, 2, 'Snake', 750, 4, 50, 25, '<p>good</p>', 'reptile3.jpg', 'snake reptile'),
(10, 5, 1, 'Carrier', 500, 1, 20, 1, '', 'petcarrier2.jpg', 'pet carrier'),
(11, 3, 2, 'Green Chameleon', 900, 4, 20, 5, '<p>Its is aswesome</p>', 'reptile2.jpg', 'green chameleon');

-- --------------------------------------------------------

--
-- Table structure for table `sortprice`
--

CREATE TABLE IF NOT EXISTS `sortprice` (
  `sort_id` int(100) NOT NULL AUTO_INCREMENT,
  `sort_title` varchar(255) NOT NULL,
  PRIMARY KEY (`sort_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `sortprice`
--

INSERT INTO `sortprice` (`sort_id`, `sort_title`) VALUES
(1, 'Choose Option'),
(2, 'Price High to Low'),
(3, 'Price Low to High');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
