<?php

$con=mysqli_connect("127.0.0.1:3308","root","","ecom");

if(mysqli_connect_errno()){

	echo"Failed to connect to Mysql" .mysqli_connect_errno();
}


?>